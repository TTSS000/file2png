// LibPNG example
// A.Greensted
// http://www.labbookpages.co.uk

// Version 2.0
// With some minor corrections to Mandlebrot code (thanks to Jan-Oliver)

// Version 1.0 - Initial release
//#define __STDC_FORMAT_MACROS
//#include <inttypes.h>
#include <stdio.h>
#include <string.h>
//#include <floatingpoint.h>
#include <math.h>
#include <malloc.h>
#include <png.h>
#include <sys/types.h>
#include <sys/stat.h>


// Creates a test image for saving. Creates a Mandelbrot Set fractal of size width x height

#if 0
float *createMandelbrotImage(int width, int height, float xS, float yS, float rad, int maxIteration);
#endif
int writeImageFromFile(char* filename, unsigned long long width,  unsigned long long  height, FILE *in_file_fp, char* title, unsigned long long in_filesize);


// This takes the float value 'val', converts it to red, green & blue values, then 
// sets those values into the image memory buffer location pointed to by 'ptr'
inline void setRGB(png_byte *ptr, float val);

// This function actually writes out the PNG image file. The string 'title' is
// also written into the image file
int writeImage(char* filename, int width, int height, float *buffer, char* title);

unsigned long long sqrt_ll64(unsigned long long in_value)
{
  unsigned long long calced_value, last_x = 0;

  printf("in_value = %llu\n", in_value);

  //decide initial value
  calced_value = 1;
  while(calced_value * calced_value < in_value){
    calced_value <<= 1;
    //printf("calced_value = %llu\n", calced_value);
  }
  //average calced_value & calced_value/2
  calced_value = 3*calced_value/4;
  //printf("calced_value 3/4 = %llu\n", calced_value);

  while( calced_value != last_x ){
    last_x = calced_value;
    calced_value = (calced_value + in_value / calced_value) / 2.0;
  }
  return calced_value;
}

int main(int argc, char *argv[])
{
  unsigned long long buffersize_temp;

	// Make sure that the output filename argument has been provided
	if (argc != 3) {
		fprintf(stderr, "usage : command_name infile output.png\n");
		return 1;
	}

	// Specify an output image size
	int width = 500;
	int height = 300;

	// Create a test image - in this case a Mandelbrot Set fractal
	// The output is a 1D array of floats, length: width * height

  char infilename[1024];
  strncpy(infilename, argv[1], 1024);
  infilename[1023] = '\0';
  //strcpy(infilename, argv[1]);
  FILE *infile_fp = fopen(infilename, "rb");
  if(NULL == infile_fp){
  fprintf(stderr, "Error - can't open infile %s\n", infilename);
    return -1;
	}

  FILE *outfile_fp = fopen(argv[2], "rb");
  if(NULL != outfile_fp){
    fprintf(stderr, "Error - outfile exist : %s\n", argv[2]);
    fclose(outfile_fp);
    return -1;
	}

  char* infilename_body_ptr;
  infilename_body_ptr = strrchr(infilename, '\\');
  if(NULL == infilename_body_ptr){
    // Windows : back slash not found
    infilename_body_ptr = infilename;
  }else{
    //  Windows : back slash found
    infilename_body_ptr++;
  }

  //obtain filesize with fstat
  struct stat infile_stat;

  fstat(infile_fp->_file, &infile_stat);

  //printf("%u\n", infile_stat.st_size);
  printf("%llu\n", infile_stat.st_size);
  //printf("%PRIu64\n", infile_stat.st_size);
  if(0 == infile_stat.st_size){
    fprintf(stderr, "Error - file %s size zero\n", infilename);
    return -1;
  }



  //calc length = filesize + 8byte
  buffersize_temp = infile_stat.st_size + sizeof(unsigned long long);
  //printf("buf temp = %llu\n", buffersize_temp);

  //calc length3 = length / 3 (RGB)
  unsigned long long buffersize_div3 = (buffersize_temp / 3) + 1;
  //printf("buffersize_div3 = %llu\n", buffersize_div3);

  //calc sqrt3len = square root of length3
  unsigned long long sqrt3ll = sqrt_ll64(buffersize_div3);
  //printf("sqrt3ll = %llu\n", sqrt3ll);

  //calc 1 + upper ceiling of sqrt3len
  sqrt3ll++;
  //printf("sqrt3ll = %llu\n", sqrt3ll);

  //calc square_len = sqrt3len^2
  unsigned long long sqrt3ll_jijo = sqrt3ll * sqrt3ll;
  //printf("sqrt3ll_jijo = %llu\n", sqrt3ll_jijo);

  // buf size = square_len * 3
  buffersize_temp = sqrt3ll_jijo * 3;
  //readfile to this buffer
  //printf("buf temp = %llu\n", buffersize_temp);

	printf("Saving PNG\n");
	int result = writeImageFromFile(argv[2], sqrt3ll, sqrt3ll, infile_fp, infilename_body_ptr, infile_stat.st_size);

  return 0;
}

inline void setRGB(png_byte *ptr, float val)
{
	int v = (int)(val * 767);
	if (v < 0) v = 0;
	if (v > 767) v = 767;
	int offset = v % 256;

	if (v<256) {
		ptr[0] = 0; ptr[1] = 0; ptr[2] = offset;
	}
	else if (v<512) {
		ptr[0] = 0; ptr[1] = offset; ptr[2] = 255-offset;
	}
	else {
		ptr[0] = offset; ptr[1] = 255-offset; ptr[2] = 0;
	}
}

int writeImageFromFile(char* filename, unsigned long long width,  unsigned long long  height, FILE *in_file_fp, char* title, unsigned long long in_filesize)
{
	int code = 0;
	FILE *fp = NULL;
	png_structp png_ptr = NULL;
	png_infop info_ptr = NULL;
	png_bytep row = NULL;
	unsigned char* file_row;
	
	// Open file for writing (binary mode)
	fp = fopen(filename, "wb");
	if (fp == NULL) {
		fprintf(stderr, "Could not open file %s for writing\n", filename);
		code = 1;
		goto finalise;
	}

	// Initialize write structure
	png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
	if (png_ptr == NULL) {
		fprintf(stderr, "Could not allocate write struct\n");
		code = 1;
		goto finalise;
	}

	// Initialize info structure
	info_ptr = png_create_info_struct(png_ptr);
	if (info_ptr == NULL) {
		fprintf(stderr, "Could not allocate info struct\n");
		code = 1;
		goto finalise;
	}

	// Setup Exception handling
	if (setjmp(png_jmpbuf(png_ptr))) {
		fprintf(stderr, "Error during png creation\n");
		code = 1;
		goto finalise;
	}

	png_init_io(png_ptr, fp);

	// Write header (8 bit colour depth)
	png_set_IHDR(png_ptr, info_ptr, width, height,
			8, PNG_COLOR_TYPE_RGB, PNG_INTERLACE_NONE,
			PNG_COMPRESSION_TYPE_BASE, PNG_FILTER_TYPE_BASE);

	// Set title
	if (title != NULL) {
		png_text title_text;
		title_text.compression = PNG_TEXT_COMPRESSION_NONE;
		title_text.key = "Title";
		title_text.text = title;
		png_set_text(png_ptr, info_ptr, &title_text, 1);
	}

	png_write_info(png_ptr, info_ptr);

	// Allocate memory for one row (3 bytes per pixel - RGB)
	//file_row = (char*) malloc(3 * width * sizeof(png_byte));
	row = (png_bytep) malloc(3 * width * sizeof(png_byte));

	// Write image data
	int x, y;
	for (y=0 ; y<height ; y++) {
    if(y == 0){
      memset(row, 0, 3 * width * sizeof(png_byte));
      memcpy(row, &in_filesize, sizeof(unsigned long long));
      fread(row+sizeof(unsigned long long), sizeof(char), 3 * width * sizeof(png_byte) - sizeof(unsigned long long), in_file_fp);
    }else{
      memset(row, 0, 3 * width * sizeof(png_byte));
      fread(row, sizeof(png_byte), 3 * width, in_file_fp);
    }
		//for (x=0 ; x<width ; x++) {
			//setRGB(&(row[x*3]), buffer[y*width + x]);
		//}
		png_write_row(png_ptr, row);
    if(y == 50*(y/50)){
      printf(".");
      fflush(stdout);
    }
	}

	// End write
	png_write_end(png_ptr, NULL);

  printf(".\n");

	finalise:
	if (fp != NULL) fclose(fp);
	if (info_ptr != NULL) png_free_data(png_ptr, info_ptr, PNG_FREE_ALL, -1);
	if (png_ptr != NULL) png_destroy_write_struct(&png_ptr, (png_infopp)NULL);
	if (row != NULL) free(row);

	return code;
}


