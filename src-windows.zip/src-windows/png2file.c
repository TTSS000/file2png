// LibPNG example
// A.Greensted
// http://www.labbookpages.co.uk

// Version 2.0
// With some minor corrections to Mandlebrot code (thanks to Jan-Oliver)

// Version 1.0 - Initial release
//#define __STDC_FORMAT_MACROS
//#include <inttypes.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
//#include <floatingpoint.h>
#include <math.h>
#include <malloc.h>
#include <png.h>
#include <sys/types.h>
#include <sys/stat.h>

/*------------------------------------------------------------*/
void PngReadFileCallback(png_structp Png,png_bytep buf,png_size_t len)
{
  int num_of_read = 0;

  //fprintf(stderr, "here 190, len = %ld\n", len);

  FILE *in_png_file_fp = (FILE *)png_get_io_ptr(Png);
  //fprintf(stderr, "here 200, in file ponter = %llx\n", in_png_file_fp);

  if(NULL == in_png_file_fp){
    fprintf(stderr, "can't get infile fp\n");
  }else{
    num_of_read = fread(buf,sizeof(png_byte), len, in_png_file_fp);
  }
  //fprintf(stderr, "num of read = %ld     \n", num_of_read);
}
/*------------------------------------------------------------*/
int main(int argc, char *argv[])
{
  unsigned long long buffersize_temp;
  png_byte sig_bytes[8];
  png_structp png = NULL;
  png_infop info = NULL;
  png_bytep row;
  png_bytepp rows;


	// Make sure that the output filename argument has been provided
	if (1 == argc || 3 < argc) {
		fprintf(stderr, "usage : command_name input.png [outfile]\n");
		fprintf(stderr, "If second argument is not specified, then use text attribute as the output filename.\n");
		return 1;
	}

	// Specify an output image size
	unsigned long width = 500;
	unsigned long height = 300;
	unsigned long depth = 8;

  char in_png_filename[256];
  strncpy(in_png_filename, argv[1], 256);
  //strcpy(infilename, argv[1]);
  FILE *in_png_file_fp = fopen(in_png_filename, "rb");
  if(NULL == in_png_file_fp){
   fprintf(stderr, "can't open infile %s\n", in_png_filename);
    return -1;
	}

  if (fread(sig_bytes, sizeof(sig_bytes), 1, in_png_file_fp) != 1) {
    return 0;
  }
  //fprintf(stderr, "here 000\n");

  if (png_sig_cmp(sig_bytes, 0, sizeof(sig_bytes))) {
    return 0;
  }
  //fprintf(stderr, "here 010\n");
  png = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
  //fprintf(stderr, "here 020\n");
  if (png == NULL) {
    goto error;
  }
  info = png_create_info_struct(png);
  //fprintf(stderr, "here 030\n");
  if (info == NULL) {
    goto error;
  }
  if (setjmp(png_jmpbuf(png))) {
    goto error;
  }
  //fprintf(stderr, "here 040\n");

  png_init_io(png, in_png_file_fp);
  //fprintf(stderr, "here 050\n");
  png_set_sig_bytes(png, sizeof(sig_bytes));
  //fprintf(stderr, "here 040\n");
  //png_read_png(png, info, PNG_TRANSFORM_PACKING | PNG_TRANSFORM_STRIP_16, NULL);
  png_read_info(png, info);
  //fprintf(stderr, "here 060\n");
  width = png_get_image_width(png, info);
  //fprintf(stderr, "here 070 width = %lu\n", width);
  fprintf(stderr, "width = %lu\n", width);
  height = png_get_image_height(png, info);
  //fprintf(stderr, "here 080 height = %lu\n", height);
  fprintf(stderr, "height = %lu\n", height);
  depth = png_get_bit_depth(png, info);
  //fprintf(stderr, "here 090\n");

  png_uint_32 num_row_bytes = png_get_rowbytes(png, info);
  //fprintf(stderr, "here 100, num_row_bytes = %lu\n", num_row_bytes);
  fprintf(stderr, "num_row_bytes = %lu\n", num_row_bytes);

  //rows = png_get_rows(png, info);

  if(PNG_COLOR_TYPE_RGB == png_get_color_type(png, info)){
    //good
  }else{
    goto error;
  }
  //fprintf(stderr, "here 110\n");

  png_bytep buf = calloc( num_row_bytes, sizeof (png_byte) );
  //fprintf(stderr, "here 120\n");

  if( buf == NULL )
        {
                png_destroy_read_struct(&png,&info,(png_infopp)NULL);
                fclose(in_png_file_fp);
                return -8;
        }

  //fprintf(stderr, "here 130\n");
  png_set_read_fn(png, in_png_file_fp, PngReadFileCallback);
  //fprintf(stderr, "here 140, in file ponter = %llx\n", in_png_file_fp);

  char out_filename[256];

  png_textp       text_ptr;
  int             num_text;
  int i;

  if(argc == 3){
    strncpy(out_filename, argv[2], 256);
    //print tExt chunk
    if (png_get_text(png, info, &text_ptr, &num_text)){
      for (i = 0; i < num_text; i++){
        fprintf(stderr,"%s = %s\n", text_ptr[i].key, text_ptr[i].text);
      }
    }
  }else{
    //print tExt chunk
    if (png_get_text(png, info, &text_ptr, &num_text)){
      for (i = 0; i < num_text; i++){
        fprintf(stderr,"%s = %s\n", text_ptr[i].key, text_ptr[i].text);
        //copy title to filename
        if(0 == strcmp("Title", text_ptr[i].key)){
          strncpy(out_filename, text_ptr[i].text, 256);
        }
      }
    }
  }

  FILE * out_file_fp = fopen(out_filename, "rb");
  if(NULL != out_file_fp){
    fprintf(stderr, "outfile exists : %s\n", out_filename);
    goto error;
    fclose(out_file_fp);
  }
  out_file_fp = fopen(out_filename, "wb");
  if(NULL == out_file_fp){
    fprintf(stderr, "can't open outfile %s\n", out_filename);
  }

  unsigned long long out_filesize;
  unsigned long long output_total = 0;
  unsigned long num_bytes;

  unsigned long count = 0;
  while(count < height){
    //fprintf(stderr, "count before = %lu\n", count);
    png_read_row(png, buf, NULL);
    //fprintf(stderr, "count after = %lu\n", count);
    if(count == 0){
      memcpy(&out_filesize, buf, sizeof(out_filesize));
      fprintf(stderr, "filesize = %ld\n", out_filesize);
      if(out_filesize < num_row_bytes){
        num_bytes = out_filesize;
      }else{
        num_bytes = num_row_bytes - sizeof(out_filesize);
      }
      fwrite(buf+sizeof(out_filesize),sizeof(png_byte), num_bytes, out_file_fp);
      output_total += num_bytes;
    }else{
      num_bytes = num_row_bytes;
      // the rest of bytes = out_filesize - output_total
      if(out_filesize - output_total < num_bytes){
         num_bytes = out_filesize - output_total;
      }
      fwrite(buf,sizeof(png_byte), num_bytes, out_file_fp);
      output_total += num_bytes;
    }
    count++;
  }
  png_read_end(png,NULL);
  num_bytes = num_row_bytes;
  // the rest of bytes = out_filesize - output_total
  if(out_filesize - output_total < num_bytes){
     num_bytes = out_filesize - output_total;
  }
  fwrite(buf,sizeof(png_byte), num_bytes, out_file_fp);
  output_total += num_bytes;


  //fprintf(stderr, "here 160\n");
  fclose(out_file_fp);

  //////////////////////////////////////////////////////////////////////////////
  //obtain filesize with fstat

  error:
  free(buf);
  png_destroy_read_struct(&png, &info, NULL);
  //fprintf(stderr, "here 170\n");
  return 0;
}


